using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangingText : MonoBehaviour
{
    public Text Texto;
    // Start is called before the first frame update
    public void NewText()
    {
        if(Texto.text == "Necesito escoger entre uno de estos carros para ganar una carrera")
        {
            Texto.text ="Hola, Mi nombre es Nanito y necesito tu ayuda.";
            return;
        }
        Texto.text = "Necesito escoger entre uno de estos carros para ganar una carrera";

    }
}
